import React from 'react';

import './Header.css';

const Header = () => (
  <div>
    Header
  </div>
);

export default Header;
